#include <iostream>
#include <vector>
#include <string>
#include "Graph.hpp"

using namespace std;

int main() {
    Graph g;

    // Create vertices A–F
    g.addVertex("A");
    g.addVertex("B");
    g.addVertex("C");
    g.addVertex("D");
    g.addVertex("E");
    g.addVertex("F");


    // Add weighted undirected edges
    g.addEdge("A", "B", 7);
    g.addEdge("A", "C", 9);
    g.addEdge("A", "F", 14);
    g.addEdge("B", "C", 10);
    g.addEdge("B", "D", 15);
    g.addEdge("C", "D", 11);
    g.addEdge("C", "F", 2);
    g.addEdge("D", "E", 6);
    g.addEdge("E", "F", 9);

    vector<string> path;

    cout << "A to B" << endl;
    unsigned long dist = g.shortestPath("A", "B", path);
    for (int i = 0; i < path.size(); i++) {
        cout << path[i];
        if (i < path.size() - 1) {
            cout << "->";
        }
    }
    cout << endl;
    cout << "Shortest path distance: " << dist << endl;

    cout << "A to C" << endl;
    dist = g.shortestPath("A", "C", path);
    for (int i = 0; i < path.size(); i++) {
        cout << path[i];
        if (i < path.size() - 1) {
            cout << "->";
        }
    }
    cout << endl;
    cout << "Shortest path distance: " << dist << endl;

    cout << "A to E" << endl;
    dist = g.shortestPath("A", "E", path);
    for (int i = 0; i < path.size(); i++) {
        cout << path[i];
        if (i < path.size() - 1) {
            cout << "->";
        }
    }
    cout << endl;
    cout << "Shortest path distance: " << dist << endl;

    cout << "A to F" << endl;
    dist = g.shortestPath("A", "F", path);
    for (int i = 0; i < path.size(); i++) {
        cout << path[i];
        if (i < path.size() - 1) {
            cout << "->";
        }
    }
    cout << endl;
    cout << "Shortest path distance: " << dist << endl;

    return 0;
}
